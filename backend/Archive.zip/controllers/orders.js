const Order = require('../models/order');

exports.getOrders = (req, res, next) => {
  Order.find()
  .populate('items')
  .exec()
  .then(rec => {
    res.status(200).json(rec);
  })
  .catch(error => {
    res.status(500).json({
      message: 'Fetching order failed!'
    });
  });
}


exports.getOrder = (req, res, next) => {
  Order.findById(req.params.id).then(order => {
    if (order) {
      res.status(200).json(order)
    } else {
      res.status(404).json({
        message: 'Order not found!'
      });
    }
  })
  .catch(error => {
    res.status(500).json({
      message: 'Fetching order failed'
    });
  });
}
